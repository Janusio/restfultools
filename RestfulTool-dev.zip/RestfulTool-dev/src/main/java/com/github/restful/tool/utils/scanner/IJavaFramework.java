package com.github.restful.tool.utils.scanner;

import com.intellij.psi.PsiClass;

/**
 * @author ZhangYuanSheng
 * @version 1.0
 */
public interface IJavaFramework extends IFrameworkHelper<PsiClass> {
}
