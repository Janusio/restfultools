/**
 * 参考 https://github.com/mrmanzhaow/RestfulToolkit
 *
 * @author ZhangYuanSheng
 * @version 1.0
 */
package com.github.restful.tool.view.search;