package com.github.restful.tool.utils.scanner;

import org.jetbrains.kotlin.psi.KtClass;

/**
 * @author ZhangYuanSheng
 * @version 1.0
 */
public interface IKotlinFramework extends IFrameworkHelper<KtClass> {
}
